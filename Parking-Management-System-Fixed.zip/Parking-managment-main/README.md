# Smart Parking Management System

A Flask + SQLite web application for managing parking entry, exit, sessions, spots, and admin reports.

## Project structure

```text
Parking-managment-main/
├── app.py
├── schema.sql
├── requirements.txt
├── templates/
│   ├── layout.html
│   ├── login.html
│   └── dashboard.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── app.js
```

## Run on Windows / VS Code

1. Open this folder in VS Code.
2. Open Terminal.
3. Create a virtual environment:

```powershell
python -m venv venv --without-pip
venv\Scripts\activate
python -m ensurepip --upgrade
python -m pip install --upgrade pip
```

4. Install dependencies:

```powershell
pip install -r requirements.txt
```

5. Start the application:

```powershell
python app.py
```

6. Open http://127.0.0.1:5000 in your browser.

## Default login

- Username: `admin`
- Password: `admin123`

The SQLite database is created automatically on the first run.

## Main features

- Admin login and session management
- Dashboard statistics
- Vehicle entry and spot allocation
- Vehicle exit and automatic fee calculation
- Active parking session list
- Search by license plate or parking/session ID
- Admin earnings reports with date filters
- SQLite persistence

## Notes

The project is configured so Flask templates are under `templates/` and static files are under `static/css/` and `static/js/`, which matches Flask's default conventions.
